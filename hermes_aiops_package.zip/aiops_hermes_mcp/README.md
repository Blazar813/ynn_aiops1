# Hermes Agent × MCP 自律型 AIOps システム

## 概要
Nous Research のオープンソースモデル「Nous-Hermes-3-Llama-3.1-8B」と、Anthropic が提唱する「Model Context Protocol (MCP)」標準を組み合わせた、Google Colab 上で完全自己完結するプライベート AIOps エージェントです。

外部 SaaS API（OpenAI / Claude API 等）への機密ログ送信を一切行わず、ローカル GPU 内で以下の ReAct サイクルを自律実行します：
1. アラート検知（payment-service の 504 Gateway Timeout）
2. MCP 経由での障害ログ調査 (`aiops_fetch_system_logs`)
3. 根本原因の推論（DBコネクション枯渇・デッドロック検知）
4. 是正措置の実行 (`aiops_execute_remediation`)

---

## 同梱ファイル一覧
- `hermes_aiops_colab.ipynb`: Google Colab 用 Jupyter Notebook（そのままアップロードして実行可能）
- `aiops_mcp_server.py`: MCP 2024-11-05 仕様に準拠した stdio 形式の AIOps サーバー
- `run_hermes_agent.py`: ローカル Hermes 3 モデルをロードして MCP ツールを動かすエージェント実行スクリプト
- `requirements.txt`: 必要最小限の依存ライブラリ一覧

---

## 実行方法 (Google Colab)
1. [Google Colaboratory](https://colab.research.google.com/) を開き、同梱の `hermes_aiops_colab.ipynb` をアップロードします。
2. 上部メニューの **「ランタイム」 > 「ランタイムのタイプを変更」** から **「T4 GPU」** を選択します。
3. セルを上から順に実行してください。
