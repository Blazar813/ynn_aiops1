import os
import sys
import json
import torch
import asyncio
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig

MODEL_ID = "NousResearch/Hermes-3-Llama-3.1-8B"

print(f"Loading local model: {MODEL_ID} (4-bit NF4 quantized for T4 GPU)...")
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.float16,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True
)

tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    quantization_config=bnb_config,
    device_map="auto"
)
print("Model loaded successfully on local GPU!")

class LocalMCPClient:
    def __init__(self, proc):
        self.proc = proc
        self._id = 0

    async def call(self, method: str, params: dict = None):
        self._id += 1
        payload = json.dumps({"jsonrpc": "2.0", "id": self._id, "method": method, "params": params or {}}) + "\n"
        self.proc.stdin.write(payload.encode())
        await self.proc.stdin.drain()

        while True:
            line = await self.proc.stdout.readline()
            if not line:
                raise ConnectionError("Server closed")
            text = line.decode().strip()
            if not text:
                continue
            res = json.loads(text)
            if res.get("id") == self._id:
                return res.get("result", {})

    async def initialize(self):
        return await self.call("initialize")

    async def list_tools(self):
        res = await self.call("tools/list")
        return res.get("tools", [])

    async def execute_tool(self, name: str, args: dict):
        res = await self.call("tools/call", {"name": name, "arguments": args})
        raw_text = res.get("content", [{}])[0].get("text", "{}")
        return json.loads(raw_text)

async def run_aiops_incident_response():
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "aiops_mcp_server.py",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    mcp_client = LocalMCPClient(proc)
    await mcp_client.initialize()

    tools = await mcp_client.list_tools()
    print(f"\n[MCP] Loaded {len(tools)} tools from MCP server:")
    for t in tools:
        print(f"  - {t['name']}: {t['description']}")

    system_prompt = f"""You are an autonomous SRE/AIOps AI Agent running in a private on-premises environment.
You investigate alerts, query logs via tools, analyze root causes, and execute remediation actions.

# Available Tools
{json.dumps(tools, ensure_ascii=False, indent=2)}

# Tool Call Format
When you need to call a tool, respond ONLY with:
<tool_call>
{{"name": "tool_name", "arguments": {{"key": "value"}}}}
</tool_call>

Once you have analyzed the logs, execute the remediation. Always provide concise thinking before tool calls.
"""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "ALERT TRIGGERED: 'payment-service' reported HTTP 504 Gateway Timeout. Investigate and remediate."}
    ]

    print("\n" + "="*60)
    print("Starting Autonomous AIOps Remediation Loop (Max 4 steps)")
    print("="*60)

    for step in range(4):
        prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=256,
                temperature=0.1,
                do_sample=False,
                pad_token_id=tokenizer.eos_token_id
            )

        new_tokens = outputs[0][inputs.input_ids.shape[1]:]
        agent_reply = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

        print(f"\n[Agent Thought & Step {step+1}]:\n{agent_reply}")
        messages.append({"role": "assistant", "content": agent_reply})

        if "<tool_call>" in agent_reply:
            raw_call = agent_reply.split("<tool_call>")[1].split("</tool_call>")[0].strip()
            try:
                call_dict = json.loads(raw_call)
                tool_name = call_dict["name"]
                tool_args = call_dict.get("arguments", {})

                print(f"\n>> [Executing MCP Tool]: {tool_name}")
                print(f">> [Arguments]: {json.dumps(tool_args, ensure_ascii=False)}")

                tool_result = await mcp_client.execute_tool(tool_name, tool_args)
                print(f">> [MCP Result]:\n{json.dumps(tool_result, ensure_ascii=False, indent=2)}")

                tool_message = f"<tool_response>\n{json.dumps(tool_result, ensure_ascii=False)}\n</tool_response>"
                messages.append({"role": "tool", "content": tool_message})

                if tool_name == "aiops_execute_remediation":
                    print("\n[Success] Incident successfully mitigated via private Hermes Agent + MCP!")
                    break

            except json.JSONDecodeError:
                print("Failed to parse tool call JSON.")
                break
        else:
            break

    proc.stdin.close()
    await proc.wait()

if __name__ == "__main__":
    asyncio.run(run_aiops_incident_response())
