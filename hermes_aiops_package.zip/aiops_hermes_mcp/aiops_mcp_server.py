import sys
import json
import asyncio
from datetime import datetime, timedelta

SAMPLE_LOG_DB = [
    {
        "timestamp": (datetime.now() - timedelta(minutes=4)).strftime("%Y-%m-%d %H:%M:%S"),
        "service_name": "payment-service",
        "level": "INFO",
        "message": "Transaction tx_1092 processed successfully in 45ms."
    },
    {
        "timestamp": (datetime.now() - timedelta(minutes=2)).strftime("%Y-%m-%d %H:%M:%S"),
        "service_name": "payment-service",
        "level": "ERROR",
        "message": "Connection pool exhausted. Database timeout after 30000ms upstream postgres-cluster."
    },
    {
        "timestamp": (datetime.now() - timedelta(minutes=1)).strftime("%Y-%m-%d %H:%M:%S"),
        "service_name": "payment-service",
        "level": "CRITICAL",
        "message": "Fatal: deadlocks detected on transaction table. Service degraded."
    }
]

TOOLS_REGISTRY = [
    {
        "name": "aiops_fetch_system_logs",
        "description": "指定されたサービスのエラーログやシステムログを取得します。",
        "parameters": {
            "type": "object",
            "properties": {
                "service_name": {"type": "string", "description": "対象サービス名 (例: payment-service)"},
                "limit": {"type": "integer", "description": "取得件数 (デフォルト5)"}
            },
            "required": ["service_name"]
        }
    },
    {
        "name": "aiops_execute_remediation",
        "description": "インシデント解決のための是正アクション（restart_service, scale_replicas, clear_cache）を実行します。",
        "parameters": {
            "type": "object",
            "properties": {
                "target_service": {"type": "string", "description": "復旧対象サービス名"},
                "action_type": {
                    "type": "string",
                    "enum": ["restart_service", "scale_replicas", "clear_cache"],
                    "description": "実行するアクション種別"
                }
            },
            "required": ["target_service", "action_type"]
        }
    }
]

def execute_tool(name: str, args: dict) -> dict:
    if name == "aiops_fetch_system_logs":
        svc = args.get("service_name", "")
        limit = args.get("limit", 5)
        logs = [l for l in SAMPLE_LOG_DB if l["service_name"] == svc][:limit]
        return {"status": "success", "service": svc, "logs": logs}

    elif name == "aiops_execute_remediation":
        action = args.get("action_type")
        target = args.get("target_service")
        return {
            "status": "SUCCESS",
            "target": target,
            "action": action,
            "executed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "message": f"Successfully performed '{action}' on service '{target}'. Health checks returned to green."
        }
    raise ValueError(f"Unknown tool: {name}")

async def main():
    loop = asyncio.get_running_loop()
    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    await loop.connect_read_pipe(lambda: protocol, sys.stdin)

    while True:
        line = await reader.readline()
        if not line:
            break
        text = line.decode().strip()
        if not text:
            continue
        try:
            req = json.loads(text)
        except Exception:
            continue

        req_id = req.get("id")
        method = req.get("method")
        params = req.get("params", {})

        if method == "initialize":
            res = {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "AIOps-Operations-Server", "version": "1.0.0"}
                }
            }
        elif method == "tools/list":
            res = {"jsonrpc": "2.0", "id": req_id, "result": {"tools": TOOLS_REGISTRY}}
        elif method == "tools/call":
            tool_name = params.get("name")
            tool_args = params.get("arguments", {})
            try:
                data = execute_tool(tool_name, tool_args)
                res = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {"content": [{"type": "text", "text": json.dumps(data, ensure_ascii=False)}]}
                }
            except Exception as e:
                res = {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32000, "message": str(e)}}
        else:
            res = {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": "Method not found"}}

        sys.stdout.write(json.dumps(res, ensure_ascii=False) + "\n")
        sys.stdout.flush()

if __name__ == "__main__":
    asyncio.run(main())
